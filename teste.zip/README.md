# Projeto de Teste para Estudo de Submodules no Git

Este projeto foi criado como um teste para aprender a trabalhar com submodules no Git. O objetivo é entender como adicionar, atualizar e gerenciar submodules em um repositório principal.
