function name(params) {
    arguments.callee
}
function name(params) {
    arguments.callee
}
function name(params) {
    arguments.callee
}
function name(params) {
    arguments.callee
}
function name(params) {
    arguments.callee
}
function name(params) {
    arguments.callee
}
function name(params) {
    arguments.callee
}
function name(params) {
    arguments.callee
}
function name(params) {
    arguments.callee
}
function name(params) {
    arguments.callee
}
function name(params) {
    arguments.callee
}
function name(params) {
    arguments.callee
}
